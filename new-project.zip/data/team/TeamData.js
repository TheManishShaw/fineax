const teamData = [
    {
        id: 1,
        name: "Manish Shaw",
        img: "/assets/images/services/face.jpg",
        post: "Front-End Developer",
        bio: "Face recognition is one of the important issues in object recognition and computer vision.Face is an important part of human being and requires detection for different applications such as security, forensic investigation.",
        facebook: "",
        github: "",
    },
    {
        id: 2,
        name: "Manish Shaw",
        img: "/assets/images/services/face.jpg",
        post: "Front-End Developer",
        bio: "Face recognition is one of the important issues in object recognition and computer vision.Face is an important part of human being and requires detection for different applications such as security, forensic investigation.",
        facebook: "",
        github: "",
    },

];

export default teamData;