"use strict";
exports.id = 903;
exports.ids = [903];
exports.modules = {

/***/ 5903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ elements_ServiceSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./pages/services/elements/SingleService.jsx
var SingleService = __webpack_require__(7844);
;// CONCATENATED MODULE: ./data/services/serviceContent.js
const serviceContent = [
    {
        id: 1,
        title: "Speech/ Audio",
        img: "/assets/images/services/face.jpg",
        description: "Face recognition is one of the important issues in object recognition and computer vision.Simply put, you cannot really discuss one without the other.",
        href: "/services/Speech"
    },
    {
        id: 2,
        title: "Computer Vision",
        img: "/assets/images/services/self_drive.jpg",
        description: "AI and self-driving cars are often complimentary topics in technology. Simply put, you cannot really discuss one without the other. ",
        link: "/services/Computer"
    },
    {
        id: 3,
        title: "Healthcare Datasets.",
        img: "/assets/images/services/doctor.jpg",
        description: "AI in medical has a great role and is future dependent, today patients are expecting lot from technologies to overcome manual surgeries to painless.",
        link: "/services/HealthCare"
    }, 
];
/* harmony default export */ const services_serviceContent = (serviceContent);

;// CONCATENATED MODULE: ./pages/services/elements/ServiceSection.jsx




const ServiceSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "text-gray-400 bg-gray-900 body-font",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container px-5 py-24 mx-auto",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-1 bg-gray-800 rounded overflow-hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-24 h-full bg-indigo-500"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-wrap sm:flex-row flex-col py-6 mb-12",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                        className: "sm:w-2/5 text-white font-medium title-font text-2xl mb-2 sm:mb-0",
                                        children: [
                                            "Our Best Solutions",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: "sm:w-3/5 leading-relaxed text-base sm:pl-10 pl-0",
                                        children: [
                                            " ",
                                            "Health Care Dataset of high - quality assurance, best for machine learning, de-identified by our Healthcare experts."
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-wrap sm:-m-4 -mx-4 -mb-10 -mt-4",
                        children: services_serviceContent.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(SingleService["default"], {
                                img: item.img,
                                title: item.title,
                                description: item.description,
                                link: item.href
                            }, item.id)
                        )
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const elements_ServiceSection = (ServiceSection);


/***/ })

};
;