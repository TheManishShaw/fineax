import React from 'react'
import Features from './elements/Features'

const index = () => {
  return (
    <div>
        <Features/>
    </div>
  )
}

export default index